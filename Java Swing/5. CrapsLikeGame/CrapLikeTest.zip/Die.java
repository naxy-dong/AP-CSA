public class Die
{
 /* instance variables not shown */
  private int minval;
  private int numsides;
  private int result;
  /** Standard six sided die numbered 1 to 6 */
  public Die()
  { 
    numsides = 6;
    minval = 1;
    result = 0;
  }

  /** roll() is a random value from minValue to minValue + sides - 1.
    * @return rollValue which is 
    * the random integer from minValue to minValue + sides -1.
    * */
  public void roll()
  {
    result = (int)(Math.random() * numsides+minval);
  }

  public int getNumDots(){
    return result;
  }
}