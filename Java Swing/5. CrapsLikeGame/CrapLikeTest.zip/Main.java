import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main extends JFrame{
  public static void main(String args[])
  {
    CrapsTest1 window2 = new CrapsTest1();
    window2.setBounds(350, 50, 300, 300);
    window2.setDefaultCloseOperation(EXIT_ON_CLOSE);
    window2.setResizable(false);
    window2.setVisible(true);
  }
}