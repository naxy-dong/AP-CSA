import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main extends JFrame{
  public static void main(String args[])
  {
    CrapsStats window = new CrapsStats();
    window.setBounds(50, 50, 300, 300);
    window.setDefaultCloseOperation(EXIT_ON_CLOSE);
    window.setResizable(false);
    window.setVisible(true);
  }
}
